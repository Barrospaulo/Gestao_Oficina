package Classes;
import java.time.LocalDate;
import java.util.Date;

public class ArranjoVeiculo {
    private static int proximoId = 0;
    private int id;
    private String matricula;
    private String tipoVeiculo;
    private int idTrabalhador;
    private int idCliente;
    private double custoTotal;
    private LocalDate dataArranjo;
    private String observacoes;

public ArranjoVeiculo(String matricula, String tipoVeiculo, int idTrabalhador, int idCliente, double custoTotal, LocalDate dataArranjo, String observacoes) {
    this.id = ++proximoId;
    this.matricula = matricula;
    this.tipoVeiculo = tipoVeiculo;
    this.idTrabalhador = idTrabalhador;
    this.idCliente = idCliente;
    this.custoTotal = custoTotal;
    this.dataArranjo = dataArranjo;
    this.observacoes = observacoes;
    }

    /**
     * @return the id
     */
    public int getId() {
        return this.id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the matricula
     */
    public String getMatricula() {
        return this.matricula;
    }

    /**
     * @param matricula the matricula to set
     */
    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    /**
     * @return the tipoVeiculo
     */
    public String getTipoVeiculo() {
        return this.tipoVeiculo;
    }

    /**
     * @param tipoVeiculo the tipoVeiculo to set
     */
    public void setTipoVeiculo(String tipoVeiculo) {
        this.tipoVeiculo = tipoVeiculo;
    }

    /**
     * @return the idTrabalhador
     */
    public int getIdTrabalhador() {
        return this.idTrabalhador;
    }

    /**
     * @param idTrabalhador the idTrabalhador to set
     */
    public void setIdTrabalhador(int idTrabalhador) {
        this.idTrabalhador = idTrabalhador;
    }

    /**
     * @return the idCliente
     */
    public int getIdCliente() {
        return this.idCliente;
    }

    /**
     * @param idCliente the idCliente to set
     */
    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    /**
     * @return the custoTotal
     */
    public double getCustoTotal() {
        return this.custoTotal;
    }
    /**
     * @param custoTotal the custoTotal to set
     */
    public void setCustoTotal(double custoTotal) {
        this.custoTotal = custoTotal;
    }

    /**
     * @return the dataArranjo
     */
    public LocalDate getDataArranjo() {
        return this.dataArranjo;
    }

    /**
     * @param dataArranjo the dataArranjo to set
     */
    public void setDataArranjo(LocalDate dataArranjo) {
        this.dataArranjo = dataArranjo;
    }

    /**
     * @return the observacoes
     */
    public String getObservacoes() {
        return this.observacoes;
    }

    /**
     * @param observacoes the observacoes to set
     */
    public void setObservacoes(String observacoes) {
        this.observacoes = observacoes;
    }
    public String getAllInfo() {
return "ID: " + this.id + "\n" + "Matricula: " + this.matricula + "\n" + "Tipo de Veiculo: " + this.tipoVeiculo + "\n" + "ID do Trabalhador: " + this.idTrabalhador + "\n" +
    "ID do Cliente: " + this.idCliente + "\n" + "Custo Total: " + this.custoTotal + "\n" + "Data do Arranjo: " + this.dataArranjo + "\n" + "Observacoes: " + this.observacoes;
    }
}




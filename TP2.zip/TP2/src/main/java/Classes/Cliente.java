package Classes;
public class Cliente {
    private static int proximoId = 0;
    private final int id;
    private String nome;
    private String contacto;
    private String nif;
    private String utilizador;
    private String senha;
    

    public Cliente(String nome, String contacto, String nif, String utilizador, String senha) {
        this.id = ++proximoId;
        this.nome = nome;
        this.contacto = contacto;
        this.nif = nif;
        this.utilizador = utilizador;
        this.senha = senha;
    }
    /**
     * @return the id
     */
    public int getId() {
        return id;
    }
    /**
     * @return the nome
     */
    public String getNome() {
        return this.nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the contacto
     */
    public String getContacto() {
        return this.contacto;
    }

    /**
     * @param contacto the contacto to set
     */
    public void setContacto(String contacto) {
        this.contacto = contacto;
    }

    /**
     * @return the nif
     */
    public String getNif() {
        return this.nif;
    }

    /**
     * @param nif the nif to set
     */
    public void setNif(String nif) {
        this.nif = nif;
    }
    /**
     * @return the utilizador
     */
    public String getUtilizador() {
        return this.utilizador;
    }
    /**
     * @param utilizador the nome to set
     */
    public void setUtilizador(String utilizador) {
        this.utilizador = utilizador;
    }
    /**
     * @return the nome
     */
    public String getSenha() {
        return this.senha;
    }

    /**
     * @param senha the nome to set
     */
    public void setSenha(String senha) {
        this.senha = senha;
    }
    public String getAllInfo() {
        return "ID: " + this.id + "\n" +
               "Nome: " + this.nome + "\n" +
               "Contacto: " + this.contacto + "\n" +
               "NIF: " + this.nif + "\n" +
               "Utilizador: " + this.utilizador + "\n" +
               "Senha: " + this.senha;
    }
}


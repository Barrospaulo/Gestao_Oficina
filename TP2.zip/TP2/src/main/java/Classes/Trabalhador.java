package Classes;
import java.util.Date;
import java.util.Scanner;

public class Trabalhador {
    private static int proximoId = 0;
    private final int id;
    private String nome;
    private int idade;
    private String contacto;
    private String cargo;
    private double salarioMensal;
    private String utilizador;
    private String senha;

    public Trabalhador(String nome, int idade, String contacto, String utilizador, String senha,String cargo, double salarioMensal) {
        this.id = ++proximoId;
        this.nome = nome;
        this.idade = idade;
        this.contacto = contacto;
        this.cargo = cargo;
        this.salarioMensal = salarioMensal;
        this.utilizador = utilizador;
        this.senha = senha;
        
    }
    /**
     * @return the id
     */
    public int getId() {
        return this.id;
    }
    /**
     * @return the nome
     */
    public String getNome() {
        return this.nome;
    }
    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the idade
     */
    public int getIdade() {
        return this.idade;
    }

    /**
     * @param idade the idade to set
     */
    public void setIdade(int idade) {
        this.idade = idade;
    }

    /**
     * @return the contacto
     */
    public String getContacto() {
        return this.contacto;
    }
    /**
     * @param contacto the contacto to set
     */
    public void setContacto(String contacto) {
        this.contacto = contacto;
    }
    /**
     * @return the cargo
     */
    public String getCargo() {
        return this.cargo;
    }
    /**
     * @param cargo the cargo to set
     */
    public void setCargo(String cargo) {
        this.cargo = cargo;
    }
    /**
     * @return the salarioMensal
     */
    public double getSalarioMensal() {
        return this.salarioMensal;
    }
    /**
     * @param salarioMensal the salarioMensal to set
     */
    public void setSalarioMensal(double salarioMensal) {
        this.salarioMensal = salarioMensal;
    }
    public String getUtilizador() {
        return this.utilizador;
    }
    /**
     * @param utilizador the nome to set
     */
    public void setUtilizador(String utilizador) {
        this.utilizador = utilizador;
    }
    public String getSenha() {
        return this.senha;
    }
    /**
     * @param senha the nome to set
     */
    public void setSenha(String senha) {
        this.senha = senha;
    }
    public String getAllInfo(){
        return "ID:" + this.id + "\n" + "Nome:" + this.nome + "\n" + "Idade:" + this.idade + "\n"
        + "Contacto:" + this.contacto + "\n" + "Utilizador:" + this.utilizador + "\n" + "Senha:" + 
        this.senha + "\n" + "Cargo:" + this.cargo + "\n" + "Salario Mensal:" + this.salarioMensal;
}
}




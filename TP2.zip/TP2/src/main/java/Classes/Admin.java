
package Classes;
public class Admin {
    private static int proximoId = 0;
    private final int id;
    private String nome;
    private int idade;
    private String contacto;
    private String utilizador;
    private String senha;

    public Admin(String nome, int idade, String contacto, String utilizador, String senha) {
        this.id = ++proximoId;
        this.nome = nome;
        this.idade = idade;
        this.contacto = contacto;
        this.utilizador = utilizador;
        this.senha = senha;
    }

    /**
     * @return the contador
     */
    public int getId() {
        return id;
    }
    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the idade
     */
    public int getIdade() {
        return idade;
    }

    /**
     * @param idade the idade to set
     */
    public void setIdade(int idade) {
        this.idade = idade;
    }

    /**
     * @return the contacto
     */
    public String getContacto() {
        return contacto;
    }

    /**
     * @param contacto the contacto to set
     */
    public void setContacto(String contacto) {
        this.contacto = contacto;
    }

    /**
     * @return the username
     */
    public String getUtilizador() {
        return utilizador;
    }

    /**
     * @param utilizador the username to set
     */
    public void setUtilizador(String utilizador) {
        this.utilizador = utilizador;
    }

    /**
     * @return the password
     */
    public String getSenha() {
        return senha;
    }

    /**
     * @param senha the password to set
     */
    public void setPassword(String senha) {
        this.senha = senha;
    }
    public String getAllInfo() {
        return "id: " + this.id + "\n" + "nome: " + this.nome + "\n" +
               "contacto: " + this.contacto + "\n" +
               "username: " + this.utilizador + "\n" +
               "password: " + this.senha;
    }
}

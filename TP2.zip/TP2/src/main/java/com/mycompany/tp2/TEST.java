/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tp2;
import java.io.FileWriter;
import java.io.IOException;
import java.io.File;
import java.util.Scanner;
import java.io.FileNotFoundException;
/**
 *
 * @author rodri
 */
public class TEST {

    public static void main (String[] args) {
        // Writing to the file
        try (FileWriter ficheiro = new FileWriter("OLA.txt")) {
            ficheiro.write("Ola a todos!");
        } catch (IOException e) {
            System.out.println("ERRO: " + e);
        }

        // Reading from the file
        try {
            File ficheiro = new File("OLA.txt");
            Scanner scanner = new Scanner(ficheiro);
            while (scanner.hasNextLine()) {
                String info = scanner.nextLine();
                System.out.println(info);
            }
            scanner.close();
        } catch (FileNotFoundException e) {
            System.out.println("ERRO: " + e);
        }
    }
}

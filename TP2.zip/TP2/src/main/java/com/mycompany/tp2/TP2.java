
package com.mycompany.tp2;

import Classes.ArranjoVeiculo;
import Classes.Cliente;
import java.util.Scanner;
import Classes.Trabalhador;
import GUI.Loginframe;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class TP2 {
    private static final List<Trabalhador> arrayTrabalhador = new ArrayList<>(); // "final" quer dizer que o valor e constante, nao pode ser alterado
    private static final List<Cliente> arrayCliente = new ArrayList<>(); // "final" quer dizer que o valor e constante, nao pode ser alterado
    private static final List<ArranjoVeiculo> arrayArranjo = new ArrayList<>(); // "final" quer dizer que o valor e constante, nao pode ser alterado
    private static final Scanner scanner = new Scanner(System.in); // "final" quer dizer que o valor e constante, nao pode ser alterado
    
    public static void main(String[] args) {
        Loginframe login = new Loginframe(); 
        login.show();
        try (scanner) {
            
           
        }
    }
}
